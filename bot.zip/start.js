const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.send('Bot Online e Conectado 24h via Render!');
});

app.listen(process.env.PORT || 8080, () => console.log('Porta 8080 ativa!'));

// Chama o arquivo de conexao correto que gerou o seu login
require('./connect.js');
