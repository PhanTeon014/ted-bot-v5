const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Bot Online!'));
app.listen(process.env.PORT || 8080, () => console.log('Porta 8080 ativa!'));

// Chama o bot original
require('./index.js');
