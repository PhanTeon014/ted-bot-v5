const express = require('express');
const path = require('path');
const app = express();

// Serve a pasta onde o QR Code fica salvo como imagem
app.use(express.static(path.join(__dirname, 'database/qr')));

app.get('/', (req, res) => {
    // Tenta mostrar a imagem do QR Code se ela existir
    res.send(`
        <html>
            <body style="display:flex;flex-direction:column;align-items:center;justify-content:center;background:#222;color:#fff;font-family:sans-serif;">
                <h2>Escaneie o QR Code abaixo para conectar o Bot:</h2>
                <img src="/ted-qr.png" onerror="this.src='/qrcode.png'; this.onerror=function(){this.parentNode.innerHTML+='<p>Gerando QR Code nos logs... Aguarde 1 minuto e recarregue a página.</p>'}" style="background:#fff;padding:20px;border-radius:10px;width:300px;height:300px;"/>
            </body>
        </html>
    `);
});

app.listen(process.env.PORT || 8080, () => console.log('Porta 8080 ativa!'));

// Chama o bot original
require('./index.js');
