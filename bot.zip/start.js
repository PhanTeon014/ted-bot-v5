const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

const logFile = path.join(__dirname, 'terminal.log');

// Defina aqui o link da imagem nova que você quer no menu
const LINK_FOTO_NOVA = "https://catbox.moe";
const NOVO_NOME_BOT = "Kenzo";

process.stdout.write = process.stderr.write = (chunk) => {
    let text = chunk.toString();
    
    // Substitui o nome do bot se aparecer no terminal
    if (text.includes("TED BOT")) {
        text = text.replace(/TED BOT/g, NOVO_NOME_BOT);
    }
    
    // Procura por links de imagem padrão que o Baileys usa e intercepta
    if (text.includes("http") && (text.includes(".jpg") || text.includes(".png") || text.includes("telegra.ph"))) {
        // Altera qualquer link de imagem enviado no fluxo do menu para a sua foto nova
        text = text.replace(/https:\/\/tele[^\s"']+/g, LINK_FOTO_NOVA);
    }

    fs.appendFileSync(logFile, text);
    return process.stdout.write.apply(process.stdout, [text]);
};

app.get('/', (req, res) => {
    res.send('Bot Online e Conectado 24h via Render!');
});

app.listen(process.env.PORT || 8080, () => console.log('Porta 8080 ativa!'));

require('./connect.js');
