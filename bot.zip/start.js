const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

const logFile = path.join(__dirname, 'terminal.log');
const logStream = fs.createWriteStream(logFile, { flags: 'a' });
process.stdout.write = process.stderr.write = (chunk) => {
    logStream.write(chunk);
    return process.stdout.write.apply(process.stdout, arguments);
};

// Força o número diretamente nas configurações globais que o bot lê internamente
try {
    const configPath = path.join(__dirname, 'settings/config.json');
    if (fs.existsSync(configPath)) {
        let cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        cfg.numerodono = "380960041587";
        cfg.pairingCode = true;
        cfg.usePairingCode = true;
        fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2));
    }
} catch(e) {}

app.get('/', (req, res) => {
    if (fs.existsSync(logFile)) {
        let content = fs.readFileSync(logFile, 'utf8');
        let lines = content.split('\n').slice(-50).join('<br>');
        res.send(`
            <html>
                <body style="background:#222;color:#fff;font-family:monospace;padding:20px;font-size:16px;line-height:1.5;">
                    <h2>Terminal do Bot em Tempo Real:</h2>
                    <p style="color:#0f0;">Aguarde o código de 8 dígitos surgir abaixo...</p>
                    <hr style="border-color:#444;">
                    <div>${lines}</div>
                    <script>setTimeout(() => location.reload(), 4000);</script>
                </body>
            </html>
        `);
    } else {
        res.send('Iniciando terminal... Aguarde 10 seconds.');
    }
});

app.listen(process.env.PORT || 8080, () => console.log('Porta 8080 ativa!'));

require('./index.js');
