const express = require('express');
const fs = require('fs');
const path = require('path');
const app = Web();

const logFile = path.join(__dirname, 'terminal.log');
const logStream = fs.createWriteStream(logFile, { flags: 'a' });

// Nome definido para o título do bot
const NOVO_NOME_BOT = "Kenzo";

process.stdout.write = process.stderr.write = (chunk) => {
    let text = chunk.toString();
    if (text.includes("TED BOT")) {
        text = text.replace(/TED BOT/g, NOVO_NOME_BOT);
    }
    logStream.write(text);
    return process.stdout.write.apply(process.stdout, [text]);
};

app.get('/', (req, res) => {
    if (fs.existsSync(logFile)) {
        let content = fs.readFileSync(logFile, 'utf8');
        let lines = content.split('\n').slice(-50).join('<br>');
        res.send(`
            <html>
                <body style="background:#222;color:#fff;font-family:monospace;padding:20px;font-size:16px;line-height:1.5;">
                    <h2>Terminal do Bot:</h2>
                    <hr style="border-color:#444;">
                    <div>${lines}</div>
                </body>
            </html>
        `);
    } else {
        res.send('Iniciando...');
    }
});

app.listen(process.env.PORT || 8080, () => console.log('Porta 8080 ativa!'));

require('./connect.js');
