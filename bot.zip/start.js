const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

// Redireciona o console do bot para um arquivo de texto para podermos ler na web
const logFile = path.join(__dirname, 'terminal.log');
const logStream = fs.createWriteStream(logFile, { flags: 'a' });
process.stdout.write = process.stderr.write = (chunk) => {
    logStream.write(chunk);
    return process.stdout.write.apply(process.stdout, arguments);
};

app.get('/', (req, res) => {
    if (fs.existsSync(logFile)) {
        let content = fs.readFileSync(logFile, 'utf8');
        // Pega as últimas linhas importantes do terminal
        let lines = content.split('\n').slice(-50).join('<br>');
        res.send(`
            <html>
                <body style="background:#222;color:#fff;font-family:monospace;padding:20px;font-size:16px;line-height:1.5;">
                    <h2>Terminal do Bot em Tempo Real:</h2>
                    <p style="color:#0f0;">Dica: Procure pelo Código de Pareamento de 8 dígitos abaixo (ex: ABCD-1234) ou aguarde ele surgir.</p>
                    <hr style="border-color:#444;">
                    <div>${lines}</div>
                    <script>setTimeout(() => location.reload(), 5000);</script>
                </body>
            </html>
        `);
    } else {
        res.send('Iniciando terminal... Aguarde 10 segundos e recarregue.');
    }
});

app.listen(process.env.PORT || 8080, () => console.log('Porta 8080 ativa!'));

// Chama o bot original
require('./index.js');
