# Ted Bot V5
